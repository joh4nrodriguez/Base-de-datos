from __future__ import division


print("Por favor ingrese los datos de la division")
dividendo=int(input("Digite el dividendo: "))
divisor=int(input("Digite el divisor: "))
division=divmod(dividendo,divisor)
print(division)
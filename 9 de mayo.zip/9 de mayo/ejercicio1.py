from math import pi
import math 
print("Programa que mostrara el resultado de la siguiente operacion A=πr2")
radio= float(input("Digite el radio: "))
operacion=math.pi*radio**2
print(operacion)
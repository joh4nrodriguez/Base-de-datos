edad1=int(input("Digite la edad de la primera persona: "))
edad2=int(input("Digite la edad de la segunda persona: "))
edad3=int(input("Digite la edad de la tercera persona: "))

promedio=(edad1+edad2+edad3)/3
print("El promedio de las edades es el siguiente" , promedio)
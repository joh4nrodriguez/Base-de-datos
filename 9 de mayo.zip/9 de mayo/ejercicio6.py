numero=(input("Digite el numero de dos cifras: "))
suma=int(numero[0])+int(numero[1])
print('La suma de las cifras es %s' %suma)
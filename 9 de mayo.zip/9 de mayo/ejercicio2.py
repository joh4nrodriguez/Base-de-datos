lado=int(input("Por favor ingresar el lado del cuadrado"))
area= lado*lado
print(area)
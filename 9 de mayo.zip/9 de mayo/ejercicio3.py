valor_articulo= float(input("Por favor ingrese el valor del articulo: "))
iva=valor_articulo*0.19
total= iva+valor_articulo
print(total)